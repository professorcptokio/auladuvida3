package com.example.duvida3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Duvida3Application {

	public static void main(String[] args) {
		SpringApplication.run(Duvida3Application.class, args);
	}

}
