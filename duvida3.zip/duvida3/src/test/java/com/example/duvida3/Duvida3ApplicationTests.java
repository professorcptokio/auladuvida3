package com.example.duvida3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Duvida3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
